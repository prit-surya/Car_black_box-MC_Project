#include <xc.h>
#include "uart.h"

#define _XTAL_FREQ 20000000  // Define the oscillator frequency (in Hz)

void init_uart(unsigned long baudrate) {
    unsigned int x;
    
    // Baud rate calculation for 8-bit asynchronous mode
    x = (_XTAL_FREQ - baudrate * 64) / (baudrate * 64);
    
    if (x > 255) {
        x = (_XTAL_FREQ - baudrate * 16) / (baudrate * 16);
        BRGH = 1;  // High speed
    } else {
        BRGH = 0;  // Low speed
    }
    
    SPBRG = x;  // Load the baud rate generator register
    SYNC = 0;   // Asynchronous mode
    SPEN = 1;   // Enable serial port pins
    TRISC7 = 1; // RX pin as input
    TRISC6 = 0; // TX pin as output
    CREN = 1;   // Enable reception
    TXEN = 1;   // Enable transmission
}

void uart_transmit(unsigned char data) {
    while (!TXIF);  // Wait until the transmit buffer is empty
    TXREG = data;   // Transmit the data
}

void uart_transmit_string(const char *data) {
    while (*data) {
        uart_transmit(*data++);
    }
}
