#ifndef UART_H
#define UART_H

void init_uart(unsigned long baudrate);
void uart_transmit(unsigned char data);
void uart_transmit_string(const char *str);

#endif  /* UART_H */
